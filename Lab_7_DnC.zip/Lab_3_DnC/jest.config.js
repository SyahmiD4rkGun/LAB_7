module.exports = {
	"preset": "@shelf/jest-mongodb"
}