const MongoClient = require("mongodb").MongoClient;
//const User = require("./user");

const client = MongoClient.connect(
	// TODO: Connection 
	"mongodb+srv://m001-student:m001-mongodb-basics@sandbox.98hil.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
	{ useNewUrlParser: true },
).catch(err => {
	console.error(err.stack)
	process.exit(1)
}).then(async client => {
	console.log('Connected to MongoDB');
	//User.injectDB(client);
})

const express = require('express')
const app = express()
const port = 3000

app.use(express.json())
app.use(express.urlencoded({ extended: false }))

app.post('/post', async (req, res) => {
    const database = client.db('testing').collection('test')
	const data = {
        name : "syahmi",
        ID_no : "1234"
    }
    const result = await database.insertOne(data)
    
      
})

app.get('/get', (req, res) => {
	res.send('Hello BENR2423')
})

app.patch('/update', async (req, res) => {
	
})

app.delete('/delete', async (req, res) => {
	
})

app.listen(port, () => {
	console.log(`Example app listening on port ${port}`)
})